// import { test, expect } from 'src/fixtures/login.fixtures';
// import { loginData } from '@/data/login.data';

// test.describe('Login Functionality Tests', () => {
//   test('SuperAdmin - Successful Login', async ({ loginPage }) => {
//     await loginPage.login(loginData.credentials.superAdmin.username, loginData.credentials.superAdmin.password);
//     await loginPage.verifyLoginSuccess();
//   });
//    test('Student - Successful Login', async ({ loginPage }) => {
//     await loginPage.login(loginData.credentials.student.username, loginData.credentials.student.password);
//   });
// });
