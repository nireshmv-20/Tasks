// import { test } from '@/fixtures/admin_fixture/academicSetup.fixtures';
// import { BrowserContext, Page } from '@playwright/test';
// import { setupContext, loginData } from '@/data/login.data';

// test.describe('Academic Setup Tests', () => {
//     let context: BrowserContext;
//     let page: Page;
//     let academicSetup: any;

//     test.beforeAll(async ({ browser }) => {
//         const setup = await setupContext(browser);
//         context = setup.context;
//         page = setup.page;
//         academicSetup = setup.academicSetup;
//         await academicSetup.redirectToPage(loginData.baseUrl.development_url);
//     });

//     test.afterAll(async () => {
//         await context?.close();
//     });

//     test('Basic validate', async () => {
//         await academicSetup.basicValidate();
//     });

//     test('Add Subject - Academic Setup', async () => {
//         await academicSetup.subjectPage.addSubject();
//     });

//     test('Add subject for physics', { tag: '@addSubject' }, async () => {
//         await academicSetup.subjectPage.newSubject();
//     });

//     test('Add Stream - Verify Stream Addition', async () => {
//         await academicSetup.streamPage.addStream();
//     });

//     test('should display error message for duplicate stream name', async () => {
//         await academicSetup.streamPage.duplicateStreamName();
//     });

//     test('edit subject', { tag: '@editSubject' }, async () => {
//         await academicSetup.subjectPage.editSubject();
//     });

//     test('View Subject', { tag: '@viewSubject' }, async () => {
//         await academicSetup.subjectPage.viewSubject();
//     });

//     test('Delete subject', { tag: '@deleteSubject' }, async () => {
//         await academicSetup.subjectPage.deleteSubject();
//     });

//     test('Cancel deletion of subject', { tag: '@cancelSubject' }, async () => {
//         await academicSetup.subjectPage.cancelDeleteSubject();
//     });

//     test('Invalid Password verfication', { tag: '@subjectDeletionInvalidPassword' }, async () => {
//         await academicSetup.subjectPage.DeletePasswordVerification();
//     });

//     test('To add a new stream', { tag: "@addSteam" }, async () => {
//         await academicSetup.streamPage.addNewStream();
//     });

//     test('Edit steam', { tag: '@editSteam' }, async () => {
//         await academicSetup.streamPage.editNewAddedStream();
//     });
    
//     test('View Stream details', { tag: '@viewSteam' }, async () => {
//         await academicSetup.streamPage.viewStream();
//     });

//     test('Delete Stream', { tag: '@deleteSteam' }, async () => {
//         await academicSetup.streamPage.deleteStream();
//     });

//     test('Cancel Deletion of Stream', { tag: '@cancelSteam' }, async () => {
//         await academicSetup.streamPage.cancelDeleteStream();
//     });

//     test('Invalid Password Verfication', { tag: '@steamDeletionInvalidPassword' }, async () => {
//         await academicSetup.streamPage.deleteInvalidPasswordVerfication();
//     });
// });
