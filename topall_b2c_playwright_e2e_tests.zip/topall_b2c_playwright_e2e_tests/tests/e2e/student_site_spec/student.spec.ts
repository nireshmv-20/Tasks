import { test } from '@/fixtures/student_fixture/login.fixture';
import { loginData } from '@/data';
import { Onboard } from '@/pages/student_page/onboardpage/onboard.page';
import { AllIndiaCompetitiveTest } from '@/pages/student_page/all_india_competitive_test/base.page';
import { all } from 'axios';

test.describe.serial('Student Onboarding', () => {
  let onboardPage: Onboard;
  let allIndiaCompetitiveTestPage: AllIndiaCompetitiveTest;

  test.beforeAll(async ({ loginPage, onboardPage: onboard, allIndiaCompetitiveTestPage: aicTestPage }) => {
    await loginPage.redirectToLoginpage();
    await loginPage.loginToHomePage();

    onboardPage = onboard;
    allIndiaCompetitiveTestPage = aicTestPage;
  });

  test('Should display validation error messages when fields are empty', async () => {
    await onboardPage.onBoardfilling_validation();
  });

  test('Should successfully fill onboarding form after login', async () => {
    await onboardPage.completeOnboardFlow();
  });

  test('Should logout successfully from the home page', async () => {
    await onboardPage.performLogout();
  });

  test('Should navigate to All India Competitive Test page', async () => {
    await allIndiaCompetitiveTestPage.redirectToAllIndiaCompetitiveTest();
  });

  test("Basic test for AICT", async () => {
    await allIndiaCompetitiveTestPage.header.basicValidation();
  })

  test("Verify Online Exam card", async () => {
    await allIndiaCompetitiveTestPage.generalinstruction.oeExamCard();
  })

  test("Should navigate to general instructionf for exam page", async () => {
    await allIndiaCompetitiveTestPage.generalinstruction.generalInstructionPage();
  })

  test("Should navigate to OE exam page", async () => {
    await allIndiaCompetitiveTestPage.oeexam.oeExamPageredirect();
  })
  test("Verify basic elements on the Online Exam page", async () => {
    await allIndiaCompetitiveTestPage.oeexam.oeExambasicVerification();
  })



});
