import { loginData } from '@/data/login.data';

export const config = {
    baseUrl: {
        development_url: loginData.baseUrl.development_url,
        demo_url: loginData.baseUrl.demo_url,
        default_url: loginData.baseUrl.development_url
    },

    superAdminCredentials: {
        username: loginData.credentials.superAdmin.username,
        password: loginData.credentials.superAdmin.password,
        publishPass: loginData.credentials.superAdmin.publish || 'defaultPublishPass'
    },
    studentCredentials: {
        username: loginData.credentials.student.username,
        password: loginData.credentials.student.password
    }
};
