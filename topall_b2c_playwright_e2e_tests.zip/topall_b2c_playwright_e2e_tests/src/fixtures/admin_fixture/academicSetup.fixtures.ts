import { test as base, expect, Page } from '@playwright/test';
import { AcademicSetup } from '@/pages/admin_page/academicSetup/base.page';
import { loginData } from '@/data/login.data';



type MyFixtures = {
    academicSetup: AcademicSetup;
};

export const test = base.extend<MyFixtures>({
    academicSetup: async ({ page }, use) => {
        const academicSetup = new AcademicSetup(page);
        await page.goto(loginData.baseUrl.development_url);
        await use(academicSetup);
    },
});

export { expect };
