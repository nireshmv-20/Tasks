export * from './academicSetup.fixtures';
