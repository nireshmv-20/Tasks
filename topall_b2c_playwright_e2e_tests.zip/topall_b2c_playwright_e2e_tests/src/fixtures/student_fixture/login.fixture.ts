import { test as base, BrowserContext, Page } from '@playwright/test';
import { LoginPage } from '@/pages/student_page/loginpage/login.page';
import { Onboard } from '@/pages/student_page/onboardpage/onboard.page';
import { AllIndiaCompetitiveTest } from '@/pages/student_page/all_india_competitive_test/base.page';
import { loginData } from '@/data';

let context: BrowserContext;

type MyFixtures = {
  loginPage: LoginPage;
  onboardPage: Onboard;
  allIndiaCompetitiveTestPage: AllIndiaCompetitiveTest;
  sharedPage: Page;
};

export const test = base.extend<MyFixtures>({
  sharedPage: async ({ browser }, use) => {
    if (!context) {
      context = await browser.newContext();
    }
    const page = await context.newPage();
    await use(page);
  },

  loginPage: async ({ sharedPage }, use) => {
    const loginPage = new LoginPage(sharedPage);
    await use(loginPage);
  },

  onboardPage: async ({ sharedPage }, use) => {
    const onboardPage = new Onboard(sharedPage);
    await use(onboardPage);
  },

  allIndiaCompetitiveTestPage: async ({ sharedPage, loginPage }, use) => {
    const allIndiaTestPage = new AllIndiaCompetitiveTest(sharedPage, loginPage);
    await use(allIndiaTestPage);
  }
});


test.afterAll(async () => {
  if (context) {
    await context.close();
  }
});
