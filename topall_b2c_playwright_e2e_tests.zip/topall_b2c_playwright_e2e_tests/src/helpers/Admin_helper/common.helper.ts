import { BaseHelper } from '../base.helper';

export class CommonHelper extends BaseHelper {}