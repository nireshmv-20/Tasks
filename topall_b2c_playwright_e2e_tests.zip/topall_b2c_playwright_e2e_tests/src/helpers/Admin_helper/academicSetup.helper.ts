import { Locator, Page } from '@playwright/test';


export class AcademicSetupHelper {
  async waitForTimeout(page: Page, timeout: number = 1000): Promise<void> {
    await page.waitForTimeout(timeout);
  }
  async clickButton(button: Locator): Promise<void> {
    await button.click();
  }
  async fillInputField(input: Locator, value: string): Promise<void> {
    await input.fill(value);
  }
  async selectDropdownOption(dropdown: Locator, option: Locator): Promise<void> {
    await dropdown.click();
    await option.click();
  }
  async waitForElementVisible(element: Locator, timeout: number = 5000): Promise<void> {
    await element.waitFor({ state: 'visible', timeout });
  }
  async pressKey(page: Page, key: string): Promise<void> {
    try {
      await page.keyboard.press(key);
    } catch (error) {
      console.error('Error pressing key:', error);
      throw error;
    }
  } 
  async takeScreenshot(page: any, path: string): Promise<void> {
    await page.screenshot({ path });
  }

  
}