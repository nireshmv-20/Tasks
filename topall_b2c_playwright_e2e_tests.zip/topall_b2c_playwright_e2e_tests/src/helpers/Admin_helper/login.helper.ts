import { Page } from 'playwright';
import { LoginPage } from '@/pages/admin_page/login.page';
import { loginData } from '@/data/login.data';

export async function performLogin(page: Page, valid: boolean) {
    const baseUrl = loginData.baseUrl;
    const loginPage = new LoginPage(page);
    await loginPage.goto(baseUrl.development_url);

    const credentials = valid ? loginData.credentials.superAdmin : loginData.credentials.student;
    await loginPage.login(credentials.username, credentials.password);
}
