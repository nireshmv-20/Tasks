import { expect, Locator } from '@playwright/test';

export class AssertionHelper {
  static async expectVisible(element: Locator): Promise<void> {
    await expect.soft(element).toBeVisible();
  }

  static async expectHidden(element: Locator): Promise<void> {
    await expect.soft(element).toBeHidden();
  }

  static async expectText(element: Locator, text: string): Promise<void> {
    await expect.soft(element).toHaveText(text);
  }

  static async expectContainsText(element: Locator, text: string): Promise<void> {
    const content = await element.textContent();
    expect.soft(content).toContain(text);
  }

  static async expectEnabled(element: Locator): Promise<void> {
    await expect.soft(element).toBeEnabled();
  }

  static async expectDisabled(element: Locator): Promise<void> {
    await expect.soft(element).toBeDisabled();
  }

  static async expectVisibleAndEnabled(element: Locator): Promise<void> {
    await expect.soft(element).toBeVisible();
    await expect.soft(element).toBeEnabled();
  }

  static async expectBackgroundColor(element: Locator, expectedColor: string): Promise<void> {
    await expect.soft(element).toHaveCSS("background-color", expectedColor);
  }
}
