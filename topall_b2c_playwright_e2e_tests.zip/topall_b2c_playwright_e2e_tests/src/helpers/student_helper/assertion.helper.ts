import { expect, Locator } from '@playwright/test';

export class AssertionHelper {
  static async expectVisible(element: Locator): Promise<void> {
    await expect(element).toBeVisible();
  }

  static async expectHidden(element: Locator): Promise<void> {
    await expect(element).toBeHidden();
  }

  static async expectText(element: Locator, text: string): Promise<void> {
    await expect(element).toHaveText(text);
  }

  static async expectContainsText(element: Locator, text: string): Promise<void> {
    const content = await element.textContent();
    expect(content).toContain(text);
  }

  static async expectEnabled(element: Locator): Promise<void> {
    await expect(element).toBeEnabled();
  }

  static async expectDisabled(element: Locator): Promise<void> {
    await expect(element).toBeDisabled();
  }

  static async expectVisibleAndEnabled(element: Locator): Promise<void> {
    await expect(element).toBeVisible();
    await expect(element).toBeEnabled();
  }
}
