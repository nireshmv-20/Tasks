import { Locator, Page } from '@playwright/test';
import { BaseHelper } from '../base.helper';
import { AssertionHelper } from '@/helpers/student_helper/assertion.helper';

export class CommonHelper extends BaseHelper {

  static async expectVisible(element: Locator): Promise<void> {
    return AssertionHelper.expectVisible(element);
  }

  static async expectHidden(element: Locator): Promise<void> {
    return AssertionHelper.expectHidden(element);
  }

  static async expectText(element: Locator, text: string): Promise<void> {
    return AssertionHelper.expectText(element, text);
  }

  static async expectContainsText(element: Locator, text: string): Promise<void> {
    return AssertionHelper.expectContainsText(element, text);
  }

  static async expectEnabled(element: Locator): Promise<void> {
    return AssertionHelper.expectEnabled(element);
  }

  static async expectDisabled(element: Locator): Promise<void> {
    return AssertionHelper.expectDisabled(element);
  }

  static async expectVisibleAndEnabled(element: Locator): Promise<void> {
    return AssertionHelper.expectVisibleAndEnabled(element);
  }

  static async expectBackgroundColor(element: Locator, expectedColor: string): Promise<void> {
    return AssertionHelper.expectBackgroundColor(element, expectedColor);
  }

}
