import { Page, Locator } from '@playwright/test';
import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

export class BaseHelper {
  static async clickButton(button: Locator): Promise<void> {
    await button.click();
  }

  static async fillInputField(inputField: Locator, value: string): Promise<void> {
    await inputField.fill(value);
  }

  static async selectDropdownOption(dropdown: Locator, option: Locator): Promise<void> {
    await dropdown.click();
    await option.click();
  }

  static async waitForElementVisible(element: Locator): Promise<void> {
    await element.waitFor({ state: 'visible' });
  }

  static async waitForTimeout(page: Page, timeout: number): Promise<void> {
    await page.waitForTimeout(timeout);
  }

  static async takeScreenshot(page: Page, filePath: string): Promise<void> {
    await page.screenshot({ path: filePath });
  }

  static async pressKey(page: Page, key: string): Promise<void> {
    await page.keyboard.press(key);
  }

  static generateAlphaSuffix(length: number): string {
    return Array.from({ length }, () => String.fromCharCode(65 + Math.floor(Math.random() * 26))).join('');
  }

  static generateMobileNumber(): string {
    const prefix = '9';
    const remainingDigits = Array.from({ length: 9 }, () => Math.floor(Math.random() * 10)).join('');
    return prefix + remainingDigits;
  }

  static async fetchOtpFromSlack(): Promise<string> {
    const SLACK_BOT_TOKEN = process.env.SLACK_BOT_TOKEN;
    const SLACK_CHANNEL_ID = process.env.SLACK_CHANNEL_ID;

    if (!SLACK_BOT_TOKEN || !SLACK_CHANNEL_ID) {
      console.warn('Slack credentials missing. Using fallback OTP: 111111');
      return '111111';
    }

    try {
      const authResponse = await axios.get('https://slack.com/api/auth.test', {
        headers: { Authorization: `Bearer ${SLACK_BOT_TOKEN}` }
      });

      if (!authResponse.data.ok) {
        console.warn('Bot authentication failed. Using fallback OTP.');
        return '111111';
      }

      const response = await axios.get('https://slack.com/api/conversations.history', {
        params: { channel: SLACK_CHANNEL_ID, limit: 10 },
        headers: { Authorization: `Bearer ${SLACK_BOT_TOKEN}` }
      });

      if (!response.data.ok) {
        console.warn('Slack API error. Using fallback OTP.');
        return '111111';
      }

      for (const message of response.data.messages) {
        const otpMatch = message.text?.match(/\b\d{6}\b/);
        if (otpMatch) return otpMatch[0];
      }

      return '111111';
    } catch (error) {
      console.warn('Error fetching OTP from Slack. Using fallback OTP.');
      return '111111';
    }
  }

  static generateUsername(prefix: string = 'TestStudent'): string {
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const timestamp = Date.now().toString(36);
    return `${prefix}_${randomNum}${timestamp}`;
  }

  static async selectDropdownByIndex(dropdown: Locator, options: Locator, index: number): Promise<void> {
    await dropdown.click();
    await options.nth(index).click();
  }

  static async waitForPageLoad(page: Page, state: 'load' | 'domcontentloaded' | 'networkidle' = 'load'): Promise<void> {
    await page.waitForLoadState(state);
  }

  static async scrollToElement(element: Locator) {
    await element.scrollIntoViewIfNeeded();
  }
}
