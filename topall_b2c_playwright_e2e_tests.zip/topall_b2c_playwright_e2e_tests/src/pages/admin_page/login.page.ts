import { Page, Locator } from '@playwright/test';

export class LoginPage {
    readonly page: Page;
    readonly emailField: Locator;
    readonly passwordField: Locator;
    readonly signInButton: Locator;
    readonly successHeading: Locator;

    constructor(page: Page) {
        this.page = page;
        this.emailField = page.locator('label:text("Email Address / User ID")');
        this.passwordField = page.locator('label:text("Password")');
        this.signInButton = page.locator('role=button[name="Sign In"]');
        this.successHeading = page.locator('role=heading[name="Dev02 Super Admin"]');
    }

    async goto(url: string) {
        await this.page.goto(url);
    }

    async login(userId: string, password: string) {
        await this.emailField.fill(userId);
        await this.passwordField.fill(password);
        await this.signInButton.click();
    }

    async verifyLoginSuccess() {
        await this.successHeading.click();
    }
}
