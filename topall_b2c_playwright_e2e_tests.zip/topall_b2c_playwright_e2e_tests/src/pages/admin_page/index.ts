export * from './login.page';
export * from './academicSetup/base.page';
export * from './academicSetup/standard.page';
export * from './academicSetup/stream.page';
export * from './academicSetup/subject.page';
export * from './academicSetup/testType.page';
