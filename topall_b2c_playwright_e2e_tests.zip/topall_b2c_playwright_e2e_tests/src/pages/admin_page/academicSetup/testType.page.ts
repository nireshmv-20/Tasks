// TestTypePage.ts

import { Page, Locator } from '@playwright/test';
import { commonHelper } from '@/helpers/Admin_helper/common.helper';
import path from 'path';
import { loginData } from '@/data/login.data';

export class TestTypePage {
  readonly page: Page;
  // Test Type-related locators
  readonly testTypeAddButton: Locator;
  readonly testTypeNameInput: Locator;
  readonly testTypeDescriptionInput: Locator;
  readonly testTypeStreamDropdown: Locator;
  readonly testTypeStreamOption: Locator;
  readonly testTypeAddButtonAction: Locator;

  constructor(page: Page) {
    this.page = page;
    // Initialize locators
    this.testTypeAddButton = page.locator('//button[@data-testid="add-testtype-btn"]');
    this.testTypeNameInput = page.locator('//input[@placeholder="Enter Test Type Name"]');
    this.testTypeDescriptionInput = page.locator('//textarea[@name="description"]');
    this.testTypeStreamDropdown = page.locator('(//span[text()="Select Stream"])[4]');
    this.testTypeStreamOption = page.locator('(//span[text()="NEET"])[6]');
    this.testTypeAddButtonAction = page.locator('//button[text()="Add"]');
  }

  async addTestType(): Promise<void> {
    try {
      const testTypeName = `TestType_${Date.now()}`;
      await commonHelper.clickButton(this.testTypeAddButton);
      await commonHelper.fillInputField(this.testTypeNameInput, testTypeName);
      await commonHelper.fillInputField(this.testTypeDescriptionInput, "Test type for NEET mock test");
      await commonHelper.selectDropdownOption(this.testTypeStreamDropdown, this.testTypeStreamOption);
      await commonHelper.clickButton(this.testTypeAddButtonAction);
      await commonHelper.waitForElementVisible(this.page.locator('text=Test Type Added Successfully'));
      console.log("Test type added successfully.");
      await commonHelper.waitForTimeout(this.page, 1000);
      await commonHelper.takeScreenshot(this.page, path.join(loginData.paths.screenshots.academicSetup, 'addTestType.png'));
    } catch (error) {
      console.error("Error in adding test type:", error);
      throw error;
    }
  }
}
