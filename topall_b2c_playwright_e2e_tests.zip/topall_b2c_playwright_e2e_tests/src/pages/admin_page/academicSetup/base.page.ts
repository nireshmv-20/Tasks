import { Page } from '@playwright/test';
import { SubjectPage } from './subject.page';
import { StreamPage } from './stream.page';
import { StandardPage } from './standard.page';
import { TestTypePage } from './testType.page';

export class AcademicSetup {
  readonly page: Page;
  readonly subjectPage: SubjectPage;
  readonly streamPage: StreamPage;
  readonly standardPage: StandardPage;
  readonly testTypePage: TestTypePage;

  constructor(page: Page) {
    this.page = page;
    this.subjectPage = new SubjectPage(page);
    this.streamPage = new StreamPage(page);
    this.standardPage = new StandardPage(page);
    this.testTypePage = new TestTypePage(page);
  }

  async redirectToPage(url: string): Promise<void> {
    await this.page.goto(url);
  }

  async basicValidate(): Promise<void> {
    const url = await this.page.url();
    const title = await this.page.title();
    console.log("Page Title:", title);
    console.log("Page URL:", url);
  }
}
