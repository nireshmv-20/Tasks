// StreamPage.ts

import { Page, Locator, expect } from '@playwright/test';
import { commonHelper } from '@/helpers/Admin_helper/common.helper';
import path from 'path';
import { loginData } from '@/data/login.data';
import { LoadHookContext } from 'module';

export class StreamPage {
  readonly page: Page;
  // Stream-related locators
  readonly streamAddButton: Locator;
  readonly streamNameInput: Locator;
  readonly streamDescriptionInput: Locator;
  readonly streamSubjectDropdown: Locator;
  readonly streamSubjectSelectAllOption: Locator;
  readonly streamSubjectDropdownOption:Locator;
  readonly streamSubjectDropdownPhysics:Locator;
  readonly streamQuestionTypeDropdown: Locator;
  readonly streamQuestionTypeSelectAllOption: Locator;
  readonly streamTotalTimeInput: Locator;
  readonly streamTotalMarksInput: Locator;
  readonly streamTimeSlotInput: Locator;
  readonly streamTotalTimeAddButton: Locator;
  readonly streamQuestionSlotInput: Locator;
  readonly streamTotalMarksAddButton: Locator;
  readonly streamCorrectMarkInput: Locator;
  readonly streamWrongMarkInput: Locator;
  readonly streamLeftMarkInput: Locator;
  readonly streamAddButtonAction: Locator;
  readonly streamNameErrorMessage: Locator;
  readonly streamEditButton:Locator;
  readonly streamUpdateButton:Locator;
  readonly streamViewName:Locator;
  readonly streamViewHeading:Locator;
  readonly streamViewExit:Locator;
  readonly streamDeleteButton:Locator;
  readonly streamPasswordInputField:Locator;
  readonly streamDeleteSubmitButton:Locator;
  readonly deleteButton:Locator;
  readonly cancelButton:Locator;
  readonly streamDeleteToastMessage:Locator;
  readonly streamInvalidPasswordToastMessage:Locator;

  constructor(page: Page) {
    this.page = page;
    // Initialize locators
    this.streamAddButton = page.locator("//button[normalize-space()='Add Stream']");
    this.streamNameInput = page.locator("//input[@name='name']");
    this.streamDescriptionInput = page.locator('//textarea[@data-test-id="subject-description"]');
    this.streamSubjectDropdown = page.locator("(//span[text()='Select options'])[1]");
    this.streamSubjectSelectAllOption = page.locator('//span[text()="Select All"]');
    this.streamSubjectDropdownOption=page.locator('//div[@id="radix-:r21:"]');
    this.streamSubjectDropdownPhysics=page.locator('//div[@data-value="Physics"]')
    this.streamQuestionTypeDropdown = page.locator('div').filter({ hasText: /^Question TypeSelect options$/ }).locator('[data-test-id="multi-select"]');
    this.streamQuestionTypeSelectAllOption = page.locator('//div[@data-test-id="select-all"]');
    this.streamTotalTimeInput = page.locator('//input[@placeholder="Enter Total Time"]');
    this.streamTotalMarksInput = page.locator('//input[@placeholder="Enter Total Marks"]');
    this.streamTimeSlotInput = page.locator('(//input[@type="text"])[3]');
    this.streamTotalTimeAddButton = page.locator('(//button[text()="Add"])[1]');
    this.streamQuestionSlotInput = page.locator('(//input[@type="text"])[4]');
    this.streamTotalMarksAddButton = page.locator('(//button[text()="Add"])[2]');
    this.streamCorrectMarkInput = page.locator('(//input[@type="text"])[5]');
    this.streamWrongMarkInput = page.locator('(//input[@type="text"])[6]');
    this.streamLeftMarkInput = page.locator('(//input[@type="text"])[7]');
    this.streamAddButtonAction = page.locator('(//button[text()="Add"])[3]');
    this.streamNameErrorMessage = page.locator("//div[contains(text(),'Already exists')]");
    this.streamEditButton=page.locator('//button[@data-testid="stream-edit-btn"]');
    this.streamUpdateButton=page.locator('//button[@data-testid="update-subject-button"]');
    this.streamViewName=page.locator('//span[@data-testid="stream-view-btn"]');
    this.streamViewHeading=page.locator('(//div[@class="flex w-full"])[1]');
    this.streamViewExit=page.locator("//span[text()='Close']");
    this.streamDeleteButton=page.locator('//button[@data-testid="stream-delete-btn"]');
    this.streamPasswordInputField=page.locator('//input[@type="password"]');
    this.streamDeleteSubmitButton=page.locator("//button[text()='Submit']");
    this.deleteButton=page.locator('//button[@data-testid="delete-confirm-button"]');
    this.cancelButton=page.locator('//button[@data-testid="cancel-delete-button"]');
    this.streamDeleteToastMessage=page.locator('//div[text()="Stream deleted successfully"]');
    this.streamInvalidPasswordToastMessage=page.locator('//div[text()="Invalid password. Please try again"]');
  }

  async addStream(): Promise<void> {
    try {
      const uniqueStreamName = `NEET_main_preparation_${Date.now()}`;
      await commonHelper.clickButton(this.streamAddButton);
      await commonHelper.fillInputField(this.streamNameInput, uniqueStreamName);
      await commonHelper.fillInputField(this.streamDescriptionInput, "Testing");
      await commonHelper.selectDropdownOption(this.streamSubjectDropdown, this.streamSubjectSelectAllOption);
      await commonHelper.pressKey(this.page, 'Escape');
      await commonHelper.selectDropdownOption(this.streamQuestionTypeDropdown, this.streamQuestionTypeSelectAllOption.first());
      await commonHelper.pressKey(this.page, 'Escape');
      await commonHelper.fillInputField(this.streamTotalTimeInput, "180");
      await commonHelper.fillInputField(this.streamTotalMarksInput, "720");
      await commonHelper.fillInputField(this.streamTimeSlotInput, "30");
      await commonHelper.clickButton(this.streamTotalTimeAddButton);
      await commonHelper.fillInputField(this.streamQuestionSlotInput, "180");
      await commonHelper.clickButton(this.streamTotalMarksAddButton);
      await commonHelper.fillInputField(this.streamCorrectMarkInput, "4");
      await commonHelper.fillInputField(this.streamWrongMarkInput, "1");
      await commonHelper.fillInputField(this.streamLeftMarkInput, "0");
      await commonHelper.clickButton(this.streamAddButtonAction);
      console.log("Stream added successfully for", uniqueStreamName);
      await commonHelper.waitForTimeout(this.page, 1000);
      await commonHelper.takeScreenshot(this.page, path.join(loginData.paths.screenshots.academicSetup, 'addStream.png'));
    } catch (error) {
      console.error("Error adding stream:", error);
      throw error;
    }
  }

  async duplicateStreamName(): Promise<void> {
    const uniqueStreamName = `NEET_main_preparation_${Date.now()}`;
    try {
      await this.addStream();
      // Attempt to add the same stream again to trigger duplicate error
      await commonHelper.clickButton(this.streamAddButton);
      await commonHelper.fillInputField(this.streamNameInput, uniqueStreamName);
      await commonHelper.fillInputField(this.streamDescriptionInput, "Testing");
      await commonHelper.selectDropdownOption(this.streamSubjectDropdown, this.streamSubjectSelectAllOption);
      await commonHelper.pressKey(this.page, 'Escape');
      await commonHelper.selectDropdownOption(this.streamQuestionTypeDropdown, this.streamQuestionTypeSelectAllOption.first());
      await commonHelper.pressKey(this.page, 'Escape');
      await commonHelper.fillInputField(this.streamTotalTimeInput, "180");
      await commonHelper.fillInputField(this.streamTotalMarksInput, "720");
      await commonHelper.fillInputField(this.streamTimeSlotInput, "30");
      await commonHelper.clickButton(this.streamTotalTimeAddButton);
      await commonHelper.fillInputField(this.streamQuestionSlotInput, "180");
      await commonHelper.clickButton(this.streamTotalMarksAddButton);
      await commonHelper.fillInputField(this.streamCorrectMarkInput, "4");
      await commonHelper.fillInputField(this.streamWrongMarkInput, "1");
      await commonHelper.fillInputField(this.streamLeftMarkInput, "0");
      await commonHelper.clickButton(this.streamAddButtonAction);
      await commonHelper.pressKey(this.page, 'Escape');
    } catch (error) {
      console.error("Error adding stream:", error);
      throw error;
    }
  }

  async addNewStream(streamBaseName: string = 'NEET'): Promise<string> {
    try {
      const uniqueStreamName = `${streamBaseName}_${Date.now()}`;
      await commonHelper.clickButton(this.streamAddButton);
      await commonHelper.fillInputField(this.streamNameInput, uniqueStreamName);
      await commonHelper.fillInputField(this.streamDescriptionInput, "This is a NEET Stream");
      await commonHelper.clickButton(this.streamSubjectDropdown);
      await commonHelper.clickButton(this.streamSubjectDropdownPhysics);
      await commonHelper.pressKey(this.page, 'Escape');
      await commonHelper.selectDropdownOption( this.streamQuestionTypeDropdown, this.streamQuestionTypeSelectAllOption.first());
      await commonHelper.pressKey(this.page, 'Escape');
      await commonHelper.fillInputField(this.streamTotalTimeInput, "180");
      await commonHelper.fillInputField(this.streamTotalMarksInput, "720");
      await commonHelper.fillInputField(this.streamTimeSlotInput, "30");
      await commonHelper.clickButton(this.streamTotalTimeAddButton);
      await commonHelper.fillInputField(this.streamQuestionSlotInput, "180");
      await commonHelper.clickButton(this.streamTotalMarksAddButton);
      await commonHelper.fillInputField(this.streamCorrectMarkInput, "4");
      await commonHelper.fillInputField(this.streamWrongMarkInput, "1");
      await commonHelper.fillInputField(this.streamLeftMarkInput, "0");
      await commonHelper.clickButton(this.streamAddButtonAction);
      console.log(`Stream '${uniqueStreamName}' added successfully.`);
      await commonHelper.waitForTimeout(this.page, 1000);
      await commonHelper.takeScreenshot(this.page, path.join(loginData.paths.screenshots.academicSetup, 'addNewStream.png'));
      return uniqueStreamName; 
    } catch (error) {
      console.error("Error adding stream:", error);
      throw error; 
    }
  }

  async editNewAddedStream(): Promise<string> {
    try {
      const originalStreamName = await this.addNewStream();
      await this.page.waitForLoadState('networkidle');
      await commonHelper.clickButton(await this.streamEditButton.last());
      const updatedStreamName = `${originalStreamName}_edit`;
      await commonHelper.fillInputField(this.streamNameInput, updatedStreamName);
      await commonHelper.clickButton(this.streamUpdateButton);  
      console.log(`Stream edited successfully. Updated name: ${updatedStreamName}`);
      await commonHelper.waitForTimeout(this.page, 1000);
      await commonHelper.takeScreenshot(this.page,  path.join(loginData.paths.screenshots.academicSetup, 'editNewStream.png'));
      return updatedStreamName; 
    } catch (error) {
      console.error("Error in editing stream:", error);
      throw error;
    }
  }
  
  async viewStream(): Promise<void> {
    try {
      await commonHelper.clickButton(await this.streamViewName.last());
      await expect(this.streamViewHeading).toBeVisible();
      await commonHelper.waitForTimeout(this.page, 1000);
      await commonHelper.takeScreenshot(this.page, path.join(loginData.paths.screenshots.academicSetup, 'ViewNewStream.png'));
      await expect(this.streamViewExit).toBeVisible();
      await commonHelper.clickButton(this.streamViewExit);
    } catch (error) {
      console.error("Error in viewing stream:", error);
      throw error; 
    }
  }

  async deleteStream(): Promise<void> {
    try {
      const streamName = await this.addNewStream();
      console.log(`Attempting to delete stream: ${streamName}`);
      await this.page.waitForLoadState('networkidle');
      await commonHelper.clickButton(await this.streamDeleteButton.last());
      await commonHelper.fillInputField(this.streamPasswordInputField, loginData.credentials.superAdmin.deletePassword);
      await commonHelper.clickButton(this.streamDeleteSubmitButton);
      await commonHelper.clickButton(this.deleteButton);
      await expect(this.streamDeleteToastMessage).toBeVisible();
      console.log(`Stream '${streamName}' deleted successfully.`);
      await commonHelper.waitForTimeout(this.page, 1000);
      await commonHelper.takeScreenshot(this.page,path.join(loginData.paths.screenshots.academicSetup, 'deleteStream.png'));
    } catch (error) {
      console.error('Error in deleteStream:', error);
      throw error; 
    }
  }
  
  async cancelDeleteStream(): Promise<void> {
    try {
      await commonHelper.clickButton(await this.streamDeleteButton.last());
      await commonHelper.fillInputField(this.streamPasswordInputField, loginData.credentials.superAdmin.deletePassword);
      await commonHelper.clickButton(this.streamDeleteSubmitButton);
      await commonHelper.clickButton(this.cancelButton);
      console.log('Stream deletion was cancelled successfully.');
      await commonHelper.waitForTimeout(this.page, 1000);
      await commonHelper.takeScreenshot(this.page, path.join(loginData.paths.screenshots.academicSetup, 'cancelDeleteStream.png'));
      const streamCancelText = await this.streamViewName.last().textContent();
      const validatedStreamText = streamCancelText ?? "";
      await expect(this.streamViewName.last()).toHaveText(validatedStreamText);
    } catch (error) {
      console.error('Error in cancelDeleteStream:', error);
      throw error; 
    }
  }

  async deleteInvalidPasswordVerfication(){
    try {
      const streamName = await this.streamViewName.last().textContent();
      console.log(`Attempting to delete stream: ${streamName}`);
      await this.page.waitForLoadState('networkidle');
      await commonHelper.clickButton(await this.streamDeleteButton.last());
      await commonHelper.fillInputField(this.streamPasswordInputField, loginData.credentials.superAdmin.invalidPassword);
      await commonHelper.clickButton(this.streamDeleteSubmitButton);
      await expect(this.streamInvalidPasswordToastMessage.last()).toBeVisible();
      console.log('Stream deletion was cancelled successfully.');
      await commonHelper.waitForTimeout(this.page, 1000);
      await commonHelper.takeScreenshot(this.page,path.join(loginData.paths.screenshots.academicSetup, 'InvalidPassword_deleteStream.png'));
    } catch (error) {
      console.error('Error in deleteStream:', error);
      throw error; 
    }
  }
}
