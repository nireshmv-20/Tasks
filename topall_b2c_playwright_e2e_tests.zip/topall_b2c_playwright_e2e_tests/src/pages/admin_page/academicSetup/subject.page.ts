// SubjectPage.ts

import { Page, Locator, expect } from '@playwright/test';
import { commonHelper } from '@/helpers/Admin_helper/common.helper';
import path from 'path';
import { loginData } from '@/data/login.data';


export class SubjectPage {
  readonly page: Page;
  // Subject-related locators
  readonly subjectAddButton: Locator;
  readonly subjectNameInput: Locator;
  readonly subjectDescriptionInput: Locator;
  readonly subjectAddButtonAction: Locator;
  readonly subjectNameErrorMessage: Locator;
  readonly subjectAddToastMessage: Locator;
  readonly subjectDuplicateToastMessage: Locator;
  readonly subjectEditButton: Locator;
  readonly subjectNameEditInput: Locator;
  readonly subjectUpdateButton: Locator;
  readonly subjectEditToastMessage: Locator;
  readonly subjectNameView: Locator;
  readonly subjectExitLocator: Locator;
  readonly viewSubjectHeading: Locator;
  readonly subjectDeleteButton: Locator;
  readonly subjectDeletePasswordField: Locator;
  readonly submitButton: Locator;
  readonly cancelButton: Locator;
  readonly deleteButton: Locator;
  readonly subjectDeleteToastMessage: Locator;
  readonly invalidPasswordToastMessage:Locator;




  constructor(page: Page) {
    this.page = page;
    // Initialize locators
    this.subjectAddButton = page.locator("//button[normalize-space()='Add Subject']");
    this.subjectNameInput = page.locator('//input[@name="name"]');
    this.subjectDescriptionInput = page.locator('//textarea[@data-test-id="subject-description"]');
    this.subjectAddButtonAction = page.locator('//button[text()="Add"]');
    this.subjectNameErrorMessage = page.locator('//div[text()="Subject name already exists"]');
    this.subjectAddToastMessage = page.locator('//div[text()="Subject added successfully"]');
    this.subjectDuplicateToastMessage = page.locator('//div[text()="Subject name already exists"]');
    this.subjectEditButton = page.locator('//button[@data-testid="subject-edit-btn"]');
    this.subjectNameEditInput = page.locator('//input[@data-test-id="subject-input"]')
    this.subjectUpdateButton = page.locator("//button[text()='Update']");
    this.subjectEditToastMessage = page.locator("//div[text()='Subject updated successfully']");
    this.subjectNameView = page.locator('//span[@data-test-id="subject-view-btn"]')
    this.subjectExitLocator = page.locator("//span[text()='Close']");
    this.viewSubjectHeading = page.locator('//div[@class="flex flex-grow flex-col"]');
    this.subjectDeleteButton = page.locator('//button[@data-testid="subject-delete-btn"]');
    this.subjectDeletePasswordField = page.locator('//input[@type="password"]');
    this.submitButton = page.locator("//button[text()='Submit']");
    this.cancelButton = page.locator('//button[@data-testid="cancel-delete-button"]');
    this.deleteButton = page.locator('//button[@data-testid="delete-confirm-button"]');
    this.subjectDeleteToastMessage = page.locator('//li[@data-type="success"]');
    this.invalidPasswordToastMessage=page.locator("//div[text()='Invalid password. Please try again']");

  }

  async addSubject(subjectName: string = `Biology_NEET_${commonHelper.generateAlphaSuffix(5)}`): Promise<void> {
    try {
      await commonHelper.clickButton(this.subjectAddButton);
      await commonHelper.fillInputField(this.subjectNameInput, subjectName);
      await commonHelper.fillInputField(this.subjectDescriptionInput, "Testing");
      await commonHelper.clickButton(this.subjectAddButtonAction);
      await commonHelper.waitForElementVisible(this.subjectAddToastMessage);
      console.log(`Subject "${subjectName}" added successfully`);
      await commonHelper.waitForTimeout(this.page, 1000);
      await commonHelper.takeScreenshot(this.page, path.join(loginData.paths.screenshots.academicSetup, `addSubject_${subjectName}.png`));
    } catch (error) {
      console.error(`Error in adding subject "${subjectName}":`, error);
      throw error;
    }
  }

  async duplicateSubjectName(subjectName: string = `Biology_NEET_${commonHelper.generateAlphaSuffix(5)}`): Promise<void> {
    try {
      console.log(`Adding the initial subject: ${subjectName}`);
      await this.addSubject(subjectName);
      console.log(`Attempting to add a duplicate subject: ${subjectName}`);
      await commonHelper.clickButton(this.subjectAddButton);
      await commonHelper.fillInputField(this.subjectNameInput, subjectName);
      await commonHelper.fillInputField(this.subjectDescriptionInput, "Testing Duplicate");
      await commonHelper.clickButton(this.subjectAddButtonAction);
      await commonHelper.waitForElementVisible(this.subjectDuplicateToastMessage);
      console.log("Duplicate subject error handled successfully.");
      const screenshotPath = path.join(loginData.paths.screenshots.academicSetup, `duplicateSubject_${subjectName}.png`);
      await commonHelper.takeScreenshot(this.page, screenshotPath);
      await commonHelper.pressKey(this.page, 'Escape');
      await commonHelper.waitForTimeout(this.page, 1000)
    } catch (error) {
      console.error(`Error handling duplicate subject '${subjectName}':`, error);
      throw error;
    }
  }

  async newSubject(subjectName: string = 'Physics'): Promise<string> {
    try {
      const uniqueSubjectName = `${subjectName}-${commonHelper.generateAlphaSuffix(5)}`;
      await commonHelper.clickButton(this.subjectAddButton);
      await commonHelper.fillInputField(this.subjectNameInput, uniqueSubjectName);
      await commonHelper.fillInputField(this.subjectDescriptionInput, "Special class for NEET");
      await commonHelper.clickButton(this.subjectAddButtonAction);
      await commonHelper.waitForElementVisible(this.subjectAddToastMessage.last());
      await expect(this.subjectAddToastMessage.last()).toBeVisible();
      console.log(`Subject '${uniqueSubjectName}' added successfully.`);
      await commonHelper.waitForTimeout(this.page, 1000);
      await commonHelper.takeScreenshot(this.page, path.join(loginData.paths.screenshots.academicSetup, 'newSubject_physics.png'));
      return uniqueSubjectName;
    } catch (error) {
      console.error("Error in adding subject:", error);
      throw error;
    }
  }

  async editSubject(subjectName: string = 'Physics'): Promise<void> {
    try {
      await this.newSubject();
      await commonHelper.clickButton(this.subjectEditButton.last());
      const alphaSuffix = commonHelper.generateAlphaSuffix(5);
      const editedSubjectName = `${subjectName}_${alphaSuffix}_edit`;
      await commonHelper.fillInputField(this.subjectNameEditInput, editedSubjectName);
      await commonHelper.fillInputField(this.subjectDescriptionInput, "Advanced prepared NEET");
      await commonHelper.clickButton(this.subjectUpdateButton);
      await commonHelper.waitForElementVisible(this.subjectEditToastMessage.last());
      await expect(this.subjectEditToastMessage).toBeVisible()
      await commonHelper.waitForTimeout(this.page, 1000);
      console.log("Subject updated successfully, the name is", editedSubjectName);
      await commonHelper.takeScreenshot(this.page, path.join(
        loginData.paths.screenshots.academicSetup, `Updated_subject_${editedSubjectName}.png`));
    } catch (error) {
      console.error("Error in editSubject:", error);
      throw error;
    }
  }

  async viewSubject() {
    try {
      await commonHelper.clickButton(this.subjectNameView.last());
      await expect(this.viewSubjectHeading).toBeVisible();
      console.log("View subject popup is opened successfully");
      await commonHelper.takeScreenshot(this.page, path.join(loginData.paths.screenshots.academicSetup, 'ViewSubject.png'));
      await commonHelper.clickButton(this.subjectExitLocator);
      console.log("Subject view closed successfully.");
    } catch (error) {
      console.error("Error occurred while viewing or closing subject:", error);
      throw error;
    }
  }

  async deleteSubject(): Promise<void> {
    try {
      await this.newSubject();
      await commonHelper.clickButton(this.subjectDeleteButton.last());
      await commonHelper.fillInputField(this.subjectDeletePasswordField, loginData.credentials.superAdmin.deletePassword);
      await commonHelper.clickButton(this.submitButton);
      await commonHelper.clickButton(this.deleteButton);
      await commonHelper.waitForElementVisible(this.subjectDeleteToastMessage.first());
      await expect(this.subjectDeleteToastMessage.first()).toBeVisible();
      console.log("Subject deleted successfully");
      await commonHelper.waitForTimeout(this.page, 1000)
      await commonHelper.takeScreenshot(this.page, path.join(loginData.paths.screenshots.academicSetup, 'deleteSubject.png'));
    } catch (error) {
      console.error("Error while deleting subject:", error);
      throw error;
    }
  }

  async cancelDeleteSubject(): Promise<void> {
    try {
      const subjectName = await this.newSubject();
      await commonHelper.clickButton(this.subjectDeleteButton.last());
      await commonHelper.fillInputField(this.subjectDeletePasswordField, loginData.credentials.superAdmin.deletePassword);
      await commonHelper.clickButton(this.submitButton);
      await commonHelper.clickButton(this.cancelButton);
      expect(this.subjectNameView.last()).toBeVisible();
      console.log(`Deletion is cancelled for the subject: ${subjectName}`);
    } catch (error) {
      console.error("Error in canceling delete subject:", error);
    }
  }

  async DeletePasswordVerification(): Promise<void> {
    try {
        const subjectName = await this.newSubject();
        await commonHelper.clickButton(this.subjectDeleteButton.last());
        await commonHelper.fillInputField(this.subjectDeletePasswordField, loginData.credentials.superAdmin.invalidPassword);
        await commonHelper.clickButton(this.submitButton);
        await commonHelper.waitForElementVisible(this.invalidPasswordToastMessage.last());
        await expect(this.invalidPasswordToastMessage).toBeVisible();
        await commonHelper.waitForTimeout(this.page, 1000);
        await commonHelper.takeScreenshot(this.page, path.join(loginData.paths.screenshots.academicSetup, 'subjectDelete_invalidPassword.png'));
        console.log(`Deletion is cancelled for the subject: ${subjectName}`);
    } catch (error) {
        console.error("Error in canceling delete subject:", error);
        throw error; 
    }
}



}


