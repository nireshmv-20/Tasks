// StandardPage.ts

import { Page, Locator } from '@playwright/test';
import { BaseHelper } from '@/helpers/base.helper';
import path from 'path';
import { loginData } from '@/data/login.data';

export class StandardPage {
  readonly page: Page;

  // Standard-related locators
  readonly standardAddButton: Locator;
  readonly standardStreamDropdown: Locator;
  readonly standardStreamOption: Locator;
  readonly standardNameInput: Locator;
  readonly standardDescriptionInput: Locator;
  readonly standardAddButtonAction: Locator;

  constructor(page: Page) {
    this.page = page;

    // Initialize locators
    this.standardAddButton = page.locator('(//button[@data-testid="subject-btn"])[3]');
    this.standardStreamDropdown = page.locator('(//span[text()="Select Stream"])[4]');
    this.standardStreamOption = page.locator('(//span[text()="NEET"])[6]');
    this.standardNameInput = page.locator('//input[@placeholder="Enter standard Name"]');
    this.standardDescriptionInput = page.locator('//textarea[@name="description"]');
    this.standardAddButtonAction = page.locator('//button[text()="Add"]');
  }

  async addStandard(): Promise<void> {
    try {
      const standardName = `Standard_${Date.now()}`;
      await BaseHelper.clickButton(this.standardAddButton);
      await BaseHelper.fillInputField(this.standardNameInput, standardName);
      await BaseHelper.fillInputField(this.standardDescriptionInput, "Standard for NEET preparation");
      await BaseHelper.selectDropdownOption(this.standardStreamDropdown, this.standardStreamOption);
      await BaseHelper.clickButton(this.standardAddButtonAction);
      await BaseHelper.waitForElementVisible(this.page.locator('text=Standard Added Successfully'));
      console.log("Standard added successfully.");
      await BaseHelper.waitForTimeout(this.page, 1000);
      await BaseHelper.takeScreenshot(this.page, path.join(loginData.paths.screenshots.academicSetup, 'addStandard.png'));
    } catch (error) {
      console.error("Error in adding standard:", error);
      throw error;
    }
  }
}
