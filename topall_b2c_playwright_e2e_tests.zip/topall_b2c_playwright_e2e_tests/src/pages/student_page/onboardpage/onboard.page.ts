import { expect, Locator, Page } from '@playwright/test';
import { BaseHelper } from '@/helpers/base.helper';
import { LoginPage } from '../loginpage/login.page';
import { basename } from 'path';
import { CommonHelper } from '@/helpers/student_helper/common.helper';

export class Onboard {
    readonly page: Page;
    readonly nameField: Locator;
    readonly stateDropdown: Locator;
    readonly stateOptions: Locator;
    readonly validationMessage: Locator;
    readonly continueButton: Locator;
    readonly neetStream: Locator;
    readonly neetStandard: Locator;
    readonly targetYeardropdown: Locator;
    readonly targetYearoption: Locator;
    readonly targetScore: Locator;
    readonly welcomeMessage: Locator;
    readonly profileMenu: Locator;
    readonly logoutButton: Locator;
    readonly signinHeader: Locator;

    private readonly defaults = {
        stateIndex: 1,
        score: '720',
        targetYearIndex: 1
    };

    constructor(page: Page) {
        this.page = page;
        this.nameField = this.page.locator('//input[@name="name"]');
        this.stateDropdown = page.locator('button[role="combobox"]');
        this.stateOptions = page.locator('div[role="option"]');
        this.validationMessage = page.locator('//p[@class="text-sm font-medium text-destructive"]');
        this.continueButton = page.locator('//button[text()="Continue"]');
        this.neetStream = page.locator('//button[text()="NEET"]');
        this.neetStandard = page.locator('//button[text()="NEET REPEATERS"]');
        this.targetYeardropdown = page.locator('//span[text()="Year"]');
        this.targetYearoption = page.locator('div[role="option"]');
        this.targetScore = page.locator('(//input[@type="text"])[3]');
        this.welcomeMessage = page.locator('//div[text()="Welcome to Topall"]');
        this.profileMenu = page.locator('//div[@aria-haspopup="menu"]');
        this.logoutButton = page.locator('//div[text()="Log Out"]');
        this.signinHeader = page.locator('//h3[text()="Sign in / Create Account"]');
    }

    async onBoardfilling_validation() {
        await BaseHelper.clickButton(this.continueButton);
        const errorMessage = this.validationMessage;
        const count = await errorMessage.count();
        for (let i = 0; i < count; i++) {
            await expect(errorMessage.nth(i)).toBeVisible();
        }
    }

    async completeOnboardFlow(
        stateName: number = this.defaults.stateIndex,
        score: string = this.defaults.score,
        targetYear: number = this.defaults.targetYearIndex
    ) {
        const username = await BaseHelper.generateUsername();

        await BaseHelper.fillInputField(this.nameField, username);
        await BaseHelper.selectDropdownByIndex(this.stateDropdown, this.stateOptions, stateName);
        await BaseHelper.clickButton(this.neetStream);
        await BaseHelper.waitForElementVisible(this.neetStandard);
        await BaseHelper.clickButton(this.neetStandard);
        await BaseHelper.selectDropdownByIndex(this.targetYeardropdown, this.targetYearoption, targetYear);
        await BaseHelper.fillInputField(this.targetScore, score);
        await BaseHelper.clickButton(this.continueButton);
        await BaseHelper.waitForElementVisible(this.welcomeMessage);
        await CommonHelper.expectVisible(this.welcomeMessage);
        return username;
    }

    async performLogout() {
        await BaseHelper.waitForPageLoad(this.page, 'load');
        await BaseHelper.waitForTimeout(this.page, 4000);
        await BaseHelper.waitForElementVisible(this.profileMenu);
        await BaseHelper.clickButton(this.profileMenu);
        await BaseHelper.clickButton(this.logoutButton);
        await CommonHelper.expectVisible(this.signinHeader);
    }
}
