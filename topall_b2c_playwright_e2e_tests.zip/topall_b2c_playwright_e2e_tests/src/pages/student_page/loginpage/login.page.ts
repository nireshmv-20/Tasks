import { Locator, Page } from "@playwright/test";
import { BaseHelper } from "@/helpers/base.helper";
import { Onboard } from "../onboardpage/onboard.page";
import { loginData } from "@/data";


export class LoginPage {
    readonly page: Page;
    readonly loginButton: Locator;
    readonly mobileNumberInput: Locator;
    readonly getOTPButton: Locator;
    readonly otpField: Locator;
    readonly continueButton: Locator;
    mobileNumber!: string;

    constructor(page: Page) {
        this.page = page;
        this.loginButton = page.locator('//button[text()="Login"]');
        this.mobileNumberInput = page.locator('//input[@placeholder="Enter Mobile Number"]');
        this.getOTPButton = page.locator('//button[text()="Get OTP"]');
        this.otpField = page.locator('//input[@placeholder="Enter OTP"]');
        this.continueButton = page.locator('//button[text()="Continue"]');
        this.mobileNumber = ""
    }

    async redirectToLoginpage() {
        await this.page.goto(loginData.baseUrl.development_url);
        await BaseHelper.clickButton(this.loginButton);
    }

    async loginToHomePage() {
        // this.mobileNumber="9884689223"
        this.mobileNumber = BaseHelper.generateMobileNumber();
        await BaseHelper.fillInputField(this.mobileNumberInput, this.mobileNumber);
        await BaseHelper.clickButton(this.getOTPButton);
        try {
            const otp = await BaseHelper.fetchOtpFromSlack();
            await BaseHelper.fillInputField(this.otpField, otp);
        } catch (error) {
            console.error('Failed to fetch OTP:', (error as Error).message);
        }
        await BaseHelper.clickButton(this.continueButton);
        return this.mobileNumber;
    }

    getMobileNumber() {
        return this.mobileNumber;
    }




}
