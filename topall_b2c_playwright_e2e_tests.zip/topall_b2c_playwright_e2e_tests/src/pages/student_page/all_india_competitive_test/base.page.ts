import { Page, Locator } from '@playwright/test';
import { BaseHelper } from '@/helpers/base.helper';
import { Onboard } from '../onboardpage/onboard.page';
import { LoginPage } from '../loginpage/login.page';
import { Header } from './header.page';
import { GeneralInstructionPage } from './general_instruction.page';
import { OEEXAMPAGE } from './oe_exam.page';
import { ResultPage } from './result.page';

export class AllIndiaCompetitiveTest {
    readonly page: Page;
    readonly onboard: Onboard;
    readonly loginPage: LoginPage;
    readonly mobileNumberInput: Locator;
    readonly getOTPButton: Locator;
    readonly otpField: Locator;
    readonly continueButton: Locator;
    readonly allIndiaCompetitiveTestModule: Locator;
    readonly header: Header;
    readonly generalinstruction: GeneralInstructionPage;
    readonly oeexam: OEEXAMPAGE;
    readonly resultpage: ResultPage;

    constructor(page: Page, loginPage: LoginPage) {
        this.page = page;
        this.onboard = new Onboard(page);
        this.loginPage = loginPage;
        this.mobileNumberInput = page.locator('//input[@placeholder="Enter Mobile Number"]');
        this.getOTPButton = page.locator('//button[text()="Get OTP"]');
        this.otpField = page.locator('//input[@placeholder="Enter OTP"]');
        this.continueButton = page.locator('//button[text()="Continue"]');
        this.allIndiaCompetitiveTestModule = page.locator('//p[text()="All India Competitive Tests"]');
        this.header = new Header(page);
        this.generalinstruction = new GeneralInstructionPage(page);
        this.oeexam = new OEEXAMPAGE(page);
        this.resultpage = new ResultPage(page);
    }

    async redirectToAllIndiaCompetitiveTest() {
        const usernumber = await this.loginPage.getMobileNumber();
        await BaseHelper.fillInputField(this.mobileNumberInput, usernumber);
        await BaseHelper.clickButton(this.getOTPButton);
        try {
            const otp = await BaseHelper.fetchOtpFromSlack();
            await BaseHelper.fillInputField(this.otpField, otp);
        } catch (error) {
            console.error('Failed to fetch OTP:', (error as Error).message);
        }
        await BaseHelper.clickButton(this.continueButton);
        await BaseHelper.clickButton(this.allIndiaCompetitiveTestModule);
    }
}
