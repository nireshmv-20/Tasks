import { Page, Locator } from 'playwright';
import { BaseHelper } from '@/helpers/base.helper';
import { expect } from 'playwright/test';
import exp from 'constants';
import { CommonHelper } from '@/helpers/student_helper/common.helper';
export class GeneralInstructionPage {
    readonly page: Page;
    readonly searchField: Locator;
    readonly viewSyllabusButton: Locator;
    readonly startTestbutton: Locator;
    readonly oeGeneralinstructionBackbutton: Locator;
    readonly oeGeneralinstructionContinuebutton: Locator;
    readonly generalInstructionheadaer: Locator;

    private readonly defaultname = {
        oeName: 'Test_Automation_Exam'
    };

    constructor(page: Page) {
        this.page = page;
        this.searchField = page.locator('//input[@type="search"]');
        this.viewSyllabusButton = page.locator('//button[text()="View Syllabus"]');
        this.startTestbutton = page.locator('//button[@data-testid="start-test-btn"]');
        this.oeGeneralinstructionBackbutton = page.locator('//button[text()="Back"]');
        this.oeGeneralinstructionContinuebutton = page.locator('//button[text()="Continue"]');
        this.generalInstructionheadaer = page.locator('//h4[text()="General Instructions"]');
    }

    async oeExamCard() {
        await BaseHelper.fillInputField(this.searchField, this.defaultname.oeName);
        await CommonHelper.expectVisibleAndEnabled(this.viewSyllabusButton);
        await CommonHelper.expectVisibleAndEnabled(this.startTestbutton);
    }

    async generalInstructionPage() {
        await BaseHelper.clickButton(this.startTestbutton);
        await CommonHelper.expectVisible(this.generalInstructionheadaer);
        await CommonHelper.expectVisibleAndEnabled(this.oeGeneralinstructionBackbutton);
        await CommonHelper.expectVisibleAndEnabled(this.oeGeneralinstructionContinuebutton);
    }
}
