import { Page, Locator } from "playwright";
import { CommonHelper } from "@/helpers/student_helper/common.helper";
import { BaseHelper } from "@/helpers/base.helper";

export class OEEXAMPAGE {
    page: Page;
    oeGeneralinstructionContinuebutton: Locator;
    readonly oeTimer: Locator;
    readonly pauseAndexitButton: Locator;
    readonly reportButton: Locator;
    readonly bookMarkButton: Locator;
    readonly oeRefresh: Locator;
    readonly subjectDropdown: Locator;
    readonly clearButton: Locator;
    readonly markForreviewButton: Locator;
    readonly saveAndnextButton: Locator;
    readonly option: Locator;
    readonly rightArrow: Locator;
    readonly leftArrow: Locator;


    constructor(page: Page) {
        this.page = page;
        this.oeGeneralinstructionContinuebutton = page.locator('//button[text()="Continue"]');
        this.oeTimer = page.locator('//span[@class="text-lg text-B2CAgrayn"]');
        this.pauseAndexitButton = page.locator('//button[text()="Pause and Exit"]');
        this.reportButton = page.locator('//span[text()="Report"]');
        this.bookMarkButton = page.locator('//span[text()="Bookmark"]');
        this.oeRefresh = page.locator('//span[text()="Refresh"]');
        this.subjectDropdown = page.locator('//button[@role="combobox"]');
        this.clearButton = page.locator('//button[text()="Clear"]');
        this.markForreviewButton = page.locator('//button[text()="Mark For Review"]');
        this.saveAndnextButton = page.locator('//button[text()="Save & Next"]');
        this.option = page.locator('//span[text()="A"]');
        this.rightArrow = page.locator("//div[@class='flex items-center gap-4']//button[2]//*[name()='svg']");
        this.leftArrow = page.locator("//div[@class='flex items-center gap-4']//button[1]//*[name()='svg']//*[name()='path' and contains(@fill,'none')]")

    }

    async oeExamPageredirect() {
        await BaseHelper.clickButton(this.oeGeneralinstructionContinuebutton);
        await BaseHelper.waitForPageLoad(this.page, "load");
    }

    async oeExambasicVerification() {
        await CommonHelper.expectVisible(this.oeTimer);
        await CommonHelper.expectVisibleAndEnabled(this.pauseAndexitButton);
        await CommonHelper.expectVisibleAndEnabled(this.reportButton);
        await CommonHelper.expectVisibleAndEnabled(this.bookMarkButton);
        await CommonHelper.expectVisibleAndEnabled(this.bookMarkButton);
        await CommonHelper.expectVisibleAndEnabled(this.subjectDropdown);
        await CommonHelper.expectVisibleAndEnabled(this.clearButton);
        await CommonHelper.expectVisibleAndEnabled(this.markForreviewButton);
        await BaseHelper.clickButton(this.option);
        await CommonHelper.expectVisibleAndEnabled(this.saveAndnextButton);
        await BaseHelper.clickButton(this.rightArrow);
        await CommonHelper.expectVisibleAndEnabled(this.rightArrow);
        await CommonHelper.expectVisibleAndEnabled(this.leftArrow);
        await BaseHelper.clickButton(this.leftArrow)





    }
}