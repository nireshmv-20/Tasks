import { Page, Locator } from 'playwright';
import { CommonHelper } from '@/helpers/student_helper/common.helper';
import { BaseHelper } from '@/helpers/base.helper';
import { basename } from 'path';
import { compileFunction } from 'vm';
import { expect } from 'playwright/test';

export class OEEXAMPAGE {
    page: Page;
    oeGeneralinstructionContinuebutton: Locator;
    readonly oeTimer: Locator;
    readonly pauseAndexitButton: Locator;
    readonly reportButton: Locator;
    readonly bookMarkButton: Locator;
    readonly oeRefresh: Locator;
    readonly subjectDropdown: Locator;
    readonly clearButton: Locator;
    readonly markForreviewButton: Locator;
    readonly saveAndnextButton: Locator;
    readonly option: Locator;
    readonly rightArrow: Locator;
    readonly leftArrow: Locator;
    readonly oeSubmitbutton: Locator;
    readonly reportCheckbox: Locator;
    readonly reportSuccessmessage: Locator;
    readonly submitButton: Locator;
    readonly clarifyBookmarkOption: Locator;
    readonly bookmarkCancelbutton: Locator;
    readonly bookmarkAddbutton: Locator;
    readonly bookmarkToastmessage: Locator;
    readonly cancelBookmarkbutton: Locator;
    readonly removeBookmarkbutton: Locator;
    readonly unbookmarkToastMessage: Locator;
    readonly optionAbutton: Locator;
    readonly questionNumberAccordion: Locator;
    readonly unansweredQuestionAccordion: Locator;
    readonly unviewedQuestionAccordion: Locator;
    readonly oeFineshbutton: Locator;
    readonly resultGreetingmessage: Locator;
    readonly submitTestbutton: Locator;

    private readonly defaultsData = {
        answeredQuestionaccordion: 'rgb(0, 168, 107)',
        unansweredQuestionaccordion: 'rgb(239, 68, 68)',
        notviewedQuestionaccordion: 'rgb(231, 231, 231)'
    };

    constructor(page: Page) {
        this.page = page;
        this.oeGeneralinstructionContinuebutton = page.locator('//button[text()="Continue"]');
        this.oeTimer = page.locator('//span[@class="text-lg text-B2CAgrayn"]');
        this.pauseAndexitButton = page.locator('//button[text()="Pause and Exit"]');
        this.reportButton = page.locator('//span[text()="Report"]');
        this.bookMarkButton = page.locator('//span[text()="Bookmark"]');
        this.oeRefresh = page.locator('//span[text()="Refresh"]');
        this.subjectDropdown = page.locator('//button[@role="combobox"]');
        this.clearButton = page.locator('//button[text()="Clear"]');
        this.markForreviewButton = page.locator('//button[text()="Mark For Review"]');
        this.saveAndnextButton = page.locator('//button[text()="Save & Next"]');
        this.option = page.locator('//span[text()="A"]');
        this.rightArrow = page.locator("//div[@class='flex items-center gap-4']//button[2]//*[name()='svg']");
        this.leftArrow = page.locator(
            "//div[@class='flex items-center gap-4']//button[1]//*[name()='svg']//*[name()='path' and contains(@fill,'none')]"
        );
        this.oeSubmitbutton = page.locator('//button[text()="Submit Test"]');
        this.reportCheckbox = page.locator('(//button[@role="checkbox"])[1]');
        this.reportSuccessmessage = page.locator('//div[text()="Issue reported successfully"]');
        this.submitButton = page.locator('//button[@data-test-id="submit-button"]');
        this.clarifyBookmarkOption = page.locator('//span[text()="Clarify Concept"]');
        this.bookmarkCancelbutton = page.locator('//button[text()="Cancel"]');
        this.bookmarkAddbutton = page.locator('//button[text()="Add"]');
        this.bookmarkToastmessage = page.locator('//div[text()="Bookmark added successfully"]');
        this.removeBookmarkbutton = page.locator('//button[text()="Remove"]');
        this.cancelBookmarkbutton = page.locator('//button[text()="Cancel"]');
        this.unbookmarkToastMessage = page.locator('//div[text()="Bookmark removed successfully"]');
        this.optionAbutton = page.locator('//span[text()="A"]');
        this.questionNumberAccordion = page.locator('//button[text()="1"]');
        this.unansweredQuestionAccordion = page.locator('//button[text()="2"]');
        this.unviewedQuestionAccordion = page.locator('//button[text()="5"]');
        this.oeFineshbutton = page.locator('//button[text()="Finish Test"]');
        this.resultGreetingmessage = page.locator('//span[text()="Your result is here "]');
        this.submitTestbutton = page.locator('//button[text()="Submit Test"]');
    }

    async oeExamPageredirect() {
        await BaseHelper.clickButton(this.oeGeneralinstructionContinuebutton);
        await BaseHelper.waitForPageLoad(this.page, 'load');
    }

    async oeExambasicVerification() {
        await CommonHelper.expectVisible(this.oeTimer);
        await CommonHelper.expectVisibleAndEnabled(this.pauseAndexitButton);
        await CommonHelper.expectVisibleAndEnabled(this.reportButton);
        await CommonHelper.expectVisibleAndEnabled(this.bookMarkButton);
        await CommonHelper.expectVisibleAndEnabled(this.bookMarkButton);
        await CommonHelper.expectVisibleAndEnabled(this.subjectDropdown);
        await CommonHelper.expectVisibleAndEnabled(this.clearButton);
        await CommonHelper.expectVisibleAndEnabled(this.markForreviewButton);
        await BaseHelper.clickButton(this.option);
        await CommonHelper.expectVisibleAndEnabled(this.saveAndnextButton);
        await BaseHelper.clickButton(this.rightArrow);
        await CommonHelper.expectVisibleAndEnabled(this.rightArrow);
        await CommonHelper.expectVisibleAndEnabled(this.leftArrow);
        await BaseHelper.clickButton(this.leftArrow);
        await CommonHelper.expectVisibleAndEnabled(this.oeSubmitbutton);
    }

    async oeReportfunctionality() {
        await BaseHelper.clickButton(this.reportButton);
        await BaseHelper.clickButton(this.reportCheckbox);
        await BaseHelper.clickButton(this.submitButton);
        await CommonHelper.expectVisible(this.reportSuccessmessage);
    }

    async oeBookmarkFunctionality() {
        await BaseHelper.clickButton(this.bookMarkButton);
        await BaseHelper.clickButton(this.clarifyBookmarkOption);
        await CommonHelper.expectVisibleAndEnabled(this.bookmarkCancelbutton);
        await CommonHelper.expectVisibleAndEnabled(this.bookmarkAddbutton);
        await BaseHelper.clickButton(this.bookmarkAddbutton);
        await CommonHelper.expectVisible(this.bookmarkToastmessage);
    }

    async oeUnbookmarkFunctionality() {
        await BaseHelper.waitForTimeout(this.page, 3000);
        await BaseHelper.clickButton(this.bookMarkButton);
        await CommonHelper.expectVisibleAndEnabled(this.removeBookmarkbutton);
        await CommonHelper.expectVisibleAndEnabled(this.cancelBookmarkbutton);
        await BaseHelper.clickButton(this.removeBookmarkbutton);
        await CommonHelper.expectVisible(this.unbookmarkToastMessage);
    }

    async validateAttendedQuestionStored() {
        await BaseHelper.clickButton(this.optionAbutton);
        await BaseHelper.clickButton(this.saveAndnextButton);
        await BaseHelper.waitForTimeout(this.page, 2000);
        await CommonHelper.expectBackgroundColor(this.questionNumberAccordion, this.defaultsData.answeredQuestionaccordion);
    }

    async validateUnansweredQuestionHighlight() {
        await BaseHelper.clickButton(this.rightArrow);
        await BaseHelper.waitForTimeout(this.page, 1000);
        await CommonHelper.expectBackgroundColor(this.unansweredQuestionAccordion, this.defaultsData.unansweredQuestionaccordion);
    }

    async ExamsubmitConfirmation() {
        await BaseHelper.clickButton(this.submitTestbutton);
        await BaseHelper.waitForPageLoad(this.page, 'networkidle');
        await CommonHelper.expectVisibleAndEnabled(this.cancelBookmarkbutton);
        await CommonHelper.expectVisibleAndEnabled(this.oeFineshbutton);
        await BaseHelper.clickButton(this.oeFineshbutton);
        await CommonHelper.expectVisible(this.resultGreetingmessage);
    }
}
