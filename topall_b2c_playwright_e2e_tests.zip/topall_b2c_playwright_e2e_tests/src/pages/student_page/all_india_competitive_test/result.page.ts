import { Page, Locator } from 'playwright';
import { CommonHelper } from '@/helpers/student_helper/common.helper';
import { BaseHelper } from '@/helpers/base.helper';

export class ResultPage {
    readonly page: Page;
    readonly overallMarkcard: Locator;
    readonly timetakenCard: Locator;
    readonly scoreChart: Locator;
    readonly leaderBoardcard: Locator;
    readonly subjectWisemarkCard: Locator;
    readonly chapterWisemarkCard: Locator;
    readonly conceptWisemarkCard: Locator;
    readonly difficultyPerformanceCard: Locator;
    readonly timeAnalysiscard: Locator;
    readonly answerKeybutton: Locator;
    readonly subjectDropdown: Locator;
    readonly difficultyDropdown: Locator;
    readonly answerKeyreportButton: Locator;
    readonly reportCheckBox: Locator;
    readonly reportSubmitbutton: Locator;
    readonly reportSuccessmessage: Locator;
    readonly answerKeyBookmarkbutton: Locator;
    readonly bookmarkOption: Locator;
    readonly bookmarkAddbutton: Locator;
    readonly bookmarkToastmessage: Locator;
    readonly bookmarkRemoveButton: Locator;
    readonly unbookmarkToastMessage: Locator;
    readonly backButton: Locator;
    readonly subjectWiseoverallCard: Locator;
    readonly zoologySubjectname: Locator;

    constructor(page: Page) {
        this.page = page;
        this.overallMarkcard = this.page.locator('//div[@class="basis-full lg:basis-8/12"]');
        this.timetakenCard = this.page.locator('//div[@class="space-y-1 p-6 sm:p-6"]');
        this.scoreChart = this.page.locator('//div[@class="grid grid-cols-2 gap-4 sm:grid-cols-2 lg:grid-cols-4"]');
        this.leaderBoardcard = this.page.locator('//h2[text()="Leaderboard"]');
        this.subjectWisemarkCard = this.page.locator('//h2[text()="Subject Wise Marks"]');
        this.chapterWisemarkCard = this.page.locator('//h2[text()="Chapter Wise Analysis"]');
        this.conceptWisemarkCard = this.page.locator('//h2[text()="Concept Wise Analysis"]');
        this.difficultyPerformanceCard = this.page.locator('//h3[text()="Difficulty Performance"]');
        this.timeAnalysiscard = this.page.locator('//h3[text()="Time Analysis"]');
        this.answerKeybutton = this.page.locator('//button[text()="Answer Key"]');
        this.subjectDropdown = this.page.locator('(//button[@type="button"])[1]');
        this.difficultyDropdown = this.page.locator('(//button[@type="button"])[2]');
        this.answerKeyreportButton = this.page.locator('(//span[text()="Report"])[1]');
        this.reportCheckBox = this.page.locator('(//button[@role="checkbox"])[1]');
        this.reportSubmitbutton = this.page.locator('//button[text()="Submit"]');
        this.reportSuccessmessage = page.locator('//div[text()="Issue reported successfully"]');
        this.answerKeyBookmarkbutton = this.page.locator('(//span[text()="Bookmark"])[1]');
        this.bookmarkOption = this.page.locator('//span[text()="Clarify Concept"]');
        this.bookmarkAddbutton = this.page.locator('//button[text()="Add"]');
        this.bookmarkToastmessage = page.locator('//div[text()="Bookmark added successfully"]');
        this.bookmarkRemoveButton = page.locator('//button[text()="Remove"]');
        this.unbookmarkToastMessage = page.locator('//div[text()="Bookmark removed successfully"]');
        this.backButton = page.locator('//span[text()="Back"]');
        this.subjectWiseoverallCard = page.locator('//div[@xpath="1"]');
        this.zoologySubjectname = page.locator('//button[text()="Zoology"]');
    }
    async resultpageCardVerification() {
        await CommonHelper.expectVisible(this.overallMarkcard);
        await CommonHelper.expectVisible(this.timetakenCard);
        await CommonHelper.expectVisible(this.scoreChart);
        await CommonHelper.expectVisible(this.leaderBoardcard);
        await CommonHelper.expectVisible(this.conceptWisemarkCard);
        await CommonHelper.expectVisible(this.difficultyPerformanceCard);
        await CommonHelper.expectVisible(this.timeAnalysiscard);
    }

    async answerKeyFunctionality() {
        await CommonHelper.expectVisibleAndEnabled(this.answerKeybutton);
        await BaseHelper.clickButton(this.answerKeybutton);
        await BaseHelper.waitForPageLoad(this.page, 'load');
        await CommonHelper.expectVisibleAndEnabled(this.subjectDropdown);
        await CommonHelper.expectVisibleAndEnabled(this.difficultyDropdown);
    }

    async answerKeyReportFunctionality() {
        await CommonHelper.expectVisibleAndEnabled(this.answerKeyreportButton);
        await BaseHelper.clickButton(this.answerKeyreportButton);
        await BaseHelper.clickButton(this.reportCheckBox);
        await BaseHelper.clickButton(this.reportSubmitbutton);
        await CommonHelper.expectVisible(this.reportSuccessmessage);
    }

    async answerKeybookMarkfunctionality() {
        await CommonHelper.expectVisibleAndEnabled(this.answerKeyBookmarkbutton);
        await BaseHelper.clickButton(this.answerKeyBookmarkbutton);
        await BaseHelper.clickButton(this.bookmarkOption);
        await BaseHelper.clickButton(this.bookmarkAddbutton);
        await CommonHelper.expectVisible(this.bookmarkToastmessage);
    }

    async answerKeyUnbookmarkFunctionality() {
        await BaseHelper.waitForPageLoad(this.page, 'load');
        await BaseHelper.clickButton(this.answerKeyBookmarkbutton);
        await BaseHelper.clickButton(this.bookmarkRemoveButton);
        await CommonHelper.expectVisible(this.unbookmarkToastMessage);
    }

    async subjectWisereport() {
        await CommonHelper.clickButton(this.backButton);
        await BaseHelper.waitForPageLoad(this.page, "load");
        await BaseHelper.scrollToElement(this.subjectWisemarkCard);
        await BaseHelper.clickButton(this.subjectWiseoverallCard.locator(this.zoologySubjectname));
        await this.page.waitForTimeout(2000);
    }
}
