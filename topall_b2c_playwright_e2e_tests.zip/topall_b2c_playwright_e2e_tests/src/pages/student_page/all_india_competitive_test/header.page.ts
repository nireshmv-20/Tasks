import { expect } from "playwright/test";
import { AllIndiaCompetitiveTest } from "./base.page";
import { Page, Locator } from "playwright";
import { AssertionHelper } from "@/helpers/student_helper/assertion.helper";
import { BaseHelper } from "@/helpers/base.helper";
import { CommonHelper } from "@/helpers/student_helper/common.helper";


export class Header {
    readonly page: Page;
    readonly aictHeading: Locator;
    readonly refreshButton: Locator;
    readonly calendarButton: Locator;
    readonly searchField: Locator;
    readonly examStartdate: Locator;
    readonly pagination: Locator;
    readonly examEnddate: Locator;


    constructor(page: Page) {
        this.page = page;
        this.aictHeading = page.locator('//h1[@class="font-medium text-B2CAgrayn text-2xl"]');
        this.refreshButton = page.locator('//button[text()="Refresh"]');
        this.calendarButton = page.locator('//button[@data-testid="calendar-btn"]');
        this.searchField = page.locator('//input[@type="search"]');
        this.examStartdate = page.locator('(//span[@class="mt-0.5"])[1]');
        this.pagination = page.locator('//nav[@aria-label="pagination"]');
        this.examEnddate = page.locator('((//span[@class="text-[#E31717]"]))[1]');
    }

    async basicValidation() {
        await CommonHelper.expectVisible(this.aictHeading);
        await CommonHelper.expectVisibleAndEnabled(this.refreshButton)
        await CommonHelper.expectVisibleAndEnabled(this.calendarButton)
        await CommonHelper.expectEnabled(this.searchField);
        await CommonHelper.expectVisible(this.examStartdate);
        await CommonHelper.expectVisibleAndEnabled(this.pagination)
        await CommonHelper.expectVisible(this.examEnddate);
    }


}

