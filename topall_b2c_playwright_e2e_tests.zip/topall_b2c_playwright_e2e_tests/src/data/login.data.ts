import path from 'path';
import { Browser, BrowserContext, Page } from '@playwright/test';
import { AcademicSetup } from '@/pages/admin_page/academicSetup/base.page';

interface LoginData {
    baseUrl: {
        development_url: string;
        staging_url: string;
        demo_url: string;
    };
    credentials: {
        superAdmin: {
            username: string;
            password: string;
            publish: string;
            deletePassword: string;
            invalidPassword: string;
        };
        student: {
            username: string;
            password: string;
        };
    };
    paths: {
        screenshots: {
            academicSetup: string;
        };
    };
}

interface SetupContext {
    context: BrowserContext;
    page: Page;
    academicSetup: AcademicSetup;
}

export const loginData: LoginData = {
    baseUrl: {
        development_url: 'https://b2c-dev01.topall.live/',
        staging_url: 'https://b2c-staging.topall.live/',
        demo_url: 'https://demo1.topall.live/',
    },
    credentials: {
        superAdmin: {
            username: '7777777777',
            password: '7777777777@Dev02',
            publish: '123456789',
            deletePassword: 'admin@123456',
            invalidPassword: "Vvtsolution"
        },
        student: {
            username: '2025108108',
            password: '2025108108@dev02',
        },
    },
    paths: {
        screenshots: {
            academicSetup: path.join(__dirname, 'screenshots', 'academicSetup'),
        },
    },
};

export async function setupContext(browser: Browser) {
    const context = await browser.newContext();
    const page = await context.newPage();
    const academicSetup = new AcademicSetup(page);

    return {
        context,
        page,
        academicSetup
    };
}
