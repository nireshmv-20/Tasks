# TopAll B2C Playwright Automation

This project, `topall_b2C_playwright_e2e_tests`, is designed to automate end-to-end testing for B2B web applications using Playwright, Cucumber, and TypeScript. It provides a comprehensive framework for creating, managing, and executing browser-based tests efficiently.

## Key Features

-   **Playwright Integration**: Employs Playwright for browser automation, mimicking real user interactions across various browsers.

-   **Cucumber for BDD**: Facilitates Behavior-Driven Development (BDD) with Cucumber, enabling test writing in natural language.

**Note**: The feature files serve solely for test scenario tracking and manual testing purposes.

-   **TypeScript Support**: Utilizes TypeScript for static type checking and access to the latest ECMAScript features, improving code quality and maintainability.

## Prerequisites

Ensure the following are installed before setting up the project:

-   Node.js (Version 18 or above, latest stable version recommended)

## Getting Started

Follow these steps to set up the project:

1. **Clone the Repository**
   Execute the following command to clone the repository:

    ```
    git clone https://your-username@bitbucket.org/vvt-solutions/topall_b2c_playwright_e2e_tests.git
    ```

2. Navigate to the Project Directory Change to the project directory using:

    ```
    cd topall_b2c_playwright_e2e_tests
    ```

3. Install Dependencies Install the required dependencies by running:

    ```
    npm install
    ```

4. Run Tests To execute the tests, use one of the following commands:

    ```
    npx playwright test
    ```

    Or, to run a specific test file:

    ```
    npx playwright test "test file name"
    ```
